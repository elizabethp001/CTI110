import turtle

tim = turtle.Turtle()

for side in range(4):
    tim.forward(100)
    tim.right(90)

for side in range(3):
    tim.forward(100)
    tim.left(120)

turtle.done()
