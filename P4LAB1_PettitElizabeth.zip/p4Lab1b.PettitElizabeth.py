import turtle

liz = turtle.Turtle()
liz.pensize(5)
liz.pencolor("Red")

liz.forward(50)
liz.backward(50)
liz.right(90)
liz.forward(100)
liz.left(90)
liz.forward(50)
liz.backward(50)
liz.right(90)
liz.forward(100)
liz.left(90)
liz.forward(50)

liz.penup()
liz.goto(100, 0)
liz.pendown()

liz.forward(50)
liz.right(90)
liz.forward(50)
liz.right(90)
liz.forward(50)
liz.right(90)
liz.forward(50)
liz.backward(100)


turtle.done()
